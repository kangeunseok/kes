var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_20221106_143924_00_merged1",
      "name": "IMG_20221106_143924_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 1.6082996783197085,
        "pitch": 0.09613843239171338,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.2862991454652821,
          "pitch": 0.11743091124797189,
          "rotation": 4.71238898038469,
          "target": "1-img_20221106_143940_00_merged1"
        },
        {
          "yaw": 2.143823769527722,
          "pitch": 0.11076451950117239,
          "rotation": 7.853981633974483,
          "target": "2-img_20221106_143957_00_merged1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-img_20221106_143940_00_merged1",
      "name": "IMG_20221106_143940_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "2-img_20221106_143957_00_merged1",
      "name": "IMG_20221106_143957_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.48669766372581336,
          "pitch": 0.1065075204870638,
          "rotation": 1.5707963267948966,
          "target": "3-img_20221106_144025_00_merged1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-img_20221106_144025_00_merged1",
      "name": "IMG_20221106_144025_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "4-img_20221106_144040_00_merged1",
      "name": "IMG_20221106_144040_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": 0.05764439145763767,
        "pitch": 0.00747363773557197,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.9370892883393651,
          "pitch": 0.09645213526611762,
          "rotation": 1.5707963267948966,
          "target": "5-img_20221106_144114_00_merged1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-img_20221106_144114_00_merged1",
      "name": "IMG_20221106_144114_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.6262937512081983,
          "pitch": 0.12009795259169209,
          "rotation": 0,
          "target": "6-img_20221106_144130_00_merged1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6-img_20221106_144130_00_merged1",
      "name": "IMG_20221106_144130_00_merged(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.7697346150387343,
          "pitch": 0.05097457515901027,
          "rotation": 0,
          "target": "5-img_20221106_144114_00_merged1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "라군인테라스2차 B1타입",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
